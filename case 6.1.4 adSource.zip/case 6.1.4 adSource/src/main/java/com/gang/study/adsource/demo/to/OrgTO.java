package com.gang.study.adsource.demo.to;

/**
 * @Classname OrgTO
 * @Description TODO
 * @Date 2020/2/19 10:16
 * @Created by zengzg
 */
public class OrgTO {


}
