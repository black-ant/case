package com.gang.study.adsource.demo.type;

/**
 * @Classname ADSearchType
 * @Description TODO
 * @Date 2020/2/20 14:21
 * @Created by zengzg
 */
public enum ADSearchType {

    EQUALS,
    ALL,
    OR;
}
