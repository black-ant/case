package com.gang.study.adsource.demo.to;

import lombok.Data;

/**
 * @Classname ADConfig
 * @Description TODO
 * @Date 2020/2/19 10:18
 * @Created by zengzg
 */
@Data
public class ADConfig {

    private String host;

    private String port;


}
