package com.gang.cxf.demo;

import org.springframework.boot.test.context.SpringBootTest;

class DemoApplicationTests {

}
