package com.gang.cxf.demo.module;

/**
 * @Classname AnyCond
 * @Description TODO
 * @Date 2019/10/31 11:04
 * @Created by ant-black 1016930479@qq.com
 */
public class AnyCond extends AttributeCond {

    private static final long serialVersionUID = -1880319220462653955L;


    public AnyCond() {
        super();
    }

    public AnyCond(final Type conditionType) {
        super(conditionType);
    }
}

