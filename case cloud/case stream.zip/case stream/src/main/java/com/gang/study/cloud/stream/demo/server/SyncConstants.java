//package com.gang.study.cloud.stream.demo.server;
//
///**
// * @Classname SyncConstants
// * @Description TODO
// * @Date 2019/11/25 14:55
// * @Created by zengzg
// */
//public final class SyncConstants {
//    public static final String SYNC_EVENT_CHANNEL = "SyncEvent";
//    public static final String SYNC_EVENT_CHANNEL_CONSUMER = "SyncEventConsumer";
//    public static final String SYNC_EVENT_CHANNEL_PRODUCER = "SyncEventProducer";
//    public static final String APP_TYPE = "APP";
//    public static final String HEADER_OPERATION = "operation";
//    public static final String HEADER_TYPE = "type";
//    public static final String HEADER_APP_TYPE = "app-type";
//    public static final String SYNC_ENTITY_CHANNEL = "SyncEntity";
//    public static final String SYNC_ENTITY_CHANNEL_CONSUMER = "SyncEntityConsumer";
//    public static final String SYNC_ENTITY_CHANNEL_PRODUCER = "SyncEntityProducer";
//
//    private SyncConstants() {
//    }
//}
//
