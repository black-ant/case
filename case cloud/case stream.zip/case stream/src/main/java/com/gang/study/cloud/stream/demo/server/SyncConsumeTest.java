//package com.gang.study.cloud.stream.demo.server;
//
//import org.springframework.cloud.stream.annotation.Input;
//import org.springframework.messaging.SubscribableChannel;
//
///**
// * @Classname SyncConsumeTest
// * @Description TODO
// * @Date 2019/11/26 13:02
// * @Created by zengzg
// */
//public interface SyncConsumeTest {
//
//    @Input("SyncTest")
//    SubscribableChannel consumer();
//}