package com.gang.study.cloud.stream.demo.entity;

import lombok.Data;

/**
 * @Classname Person
 * @Description TODO
 * @Date 2019/11/12 11:34
 * @Created by ant-black 1016930479@qq.com
 */
@Data
public class Person {

    private String name;
    private String username;
    private Integer age;
}
