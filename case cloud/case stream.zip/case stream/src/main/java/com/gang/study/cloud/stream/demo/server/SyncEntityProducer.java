//package com.gang.study.cloud.stream.demo.server;
//
//import org.springframework.cloud.stream.annotation.Output;
//import org.springframework.messaging.MessageChannel;
//
///**
// * @Classname SyncEntityProducer
// * @Description TODO
// * @Date 2019/11/25 14:55
// * @Created by zengzg
// */
//public interface SyncEntityProducer {
//    String CHANNEL = "SyncEntity";
//
//    @Output("SyncEntity")
//    MessageChannel producer();
//}
//
