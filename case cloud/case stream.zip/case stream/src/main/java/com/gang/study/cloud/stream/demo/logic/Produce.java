package com.gang.study.cloud.stream.demo.logic;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;
import para.cic.idm.common.sync.api.SyncConstants;
import para.cic.idm.common.sync.api.SyncEventProducer;

/**
 * @Classname Produce
 * @Description TODO
 * @Date 2019/11/25 14:57
 * @Created by zengzg
 */
@Component
public class Produce {

    //    @Autowired(required = false)
    //    private SyncProduceTest syncProduceTest;
    //
    //    public void send() {
    //        syncProduceTest.producer().send(MessageBuilder.withPayload("hello " +
    //                "stream").setHeader(SyncConstants.HEADER_OPERATION,
    //                "create").setHeader(SyncConstants.HEADER_TYPE, "org").setHeader(SyncConstants.HEADER_APP_TYPE,
    //                "ding").build());
    //    }

    @Autowired(required = false)
    private SyncEventProducer syncEventProducer;

    public void sendMain() {
        syncEventProducer.producer().send(MessageBuilder.withPayload("hello1 " +
                "stream").setHeader(SyncConstants.HEADER_OPERATION,
                "create").setHeader(SyncConstants.HEADER_TYPE, "org").setHeader(SyncConstants.HEADER_APP_TYPE,
                "ding").build());
    }

}
