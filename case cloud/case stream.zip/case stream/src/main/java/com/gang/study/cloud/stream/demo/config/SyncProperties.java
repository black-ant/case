//package com.gang.study.cloud.stream.demo.config;
//
//import org.springframework.boot.context.properties.ConfigurationProperties;
//
///**
// * @Classname SyncProperties
// * @Description TODO
// * @Date 2019/11/25 14:57
// * @Created by zengzg
// */
//
//@ConfigurationProperties(
//        prefix = "com.gang.study.cloud.stream"
//)
//public class SyncProperties {
//    public static final String PREFIX = "com.gang.study.cloud.stream";
//    private boolean enable = true;
//    private boolean eventProducer = true;
//    private boolean eventConsumer = true;
//    private boolean entityProducer = true;
//    private boolean entityConsumer = true;
//
//    public SyncProperties() {
//    }
//
//    public boolean isEnable() {
//        return this.enable;
//    }
//
//    public void setEnable(boolean enable) {
//        this.enable = enable;
//    }
//
//    public boolean isEventProducer() {
//        return this.eventProducer;
//    }
//
//    public void setEventProducer(boolean eventProducer) {
//        this.eventProducer = eventProducer;
//    }
//
//    public boolean isEventConsumer() {
//        return this.eventConsumer;
//    }
//
//    public void setEventConsumer(boolean eventConsumer) {
//        this.eventConsumer = eventConsumer;
//    }
//
//    public boolean isEntityProducer() {
//        return this.entityProducer;
//    }
//
//    public void setEntityProducer(boolean entityProducer) {
//        this.entityProducer = entityProducer;
//    }
//
//    public boolean isEntityConsumer() {
//        return this.entityConsumer;
//    }
//
//    public void setEntityConsumer(boolean entityConsumer) {
//        this.entityConsumer = entityConsumer;
//    }
//}
