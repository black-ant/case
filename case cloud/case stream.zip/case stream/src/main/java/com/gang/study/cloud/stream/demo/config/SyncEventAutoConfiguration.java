//package com.gang.study.cloud.stream.demo.config;
//
//import org.springframework.boot.autoconfigure.AutoConfigureOrder;
//import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
//import org.springframework.boot.context.properties.EnableConfigurationProperties;
//import org.springframework.cloud.stream.annotation.EnableBinding;
//import org.springframework.context.annotation.Configuration;
//import para.cic.idm.common.sync.api.SyncEntityConsumer;
//import para.cic.idm.common.sync.api.SyncEntityProducer;
//import para.cic.idm.common.sync.api.SyncEventConsumer;
//import para.cic.idm.common.sync.api.SyncEventProducer;
//
///**
// * @Classname SyncEventAutoConfiguration
// * @Description TODO
// * @Date 2019/11/25 14:54
// * @Created by zengzg
// */
//@Configuration
//@EnableConfigurationProperties({SyncProperties.class})
//@AutoConfigureOrder(2147483646)
//@ConditionalOnProperty(
//        name = {"com.gang.study.cloud.stream.enable"},
//        havingValue = "true",
//        matchIfMissing = true
//)
//public class SyncEventAutoConfiguration {
//    public SyncEventAutoConfiguration() {
//    }
//
//    @ConditionalOnProperty(
//            name = {"com.gang.study.cloud.stream.entity-producer"},
//            havingValue = "true",
//            matchIfMissing = false
//    )
//    @EnableBinding({SyncEntityProducer.class})
//    public class EntityProducer {
//        public EntityProducer() {
//        }
//    }
//
//    @ConditionalOnProperty(
//            name = {"com.gang.study.cloud.stream.event-consumer"},
//            havingValue = "true",
//            matchIfMissing = false
//    )
//
//    @EnableBinding({SyncEventConsumer.class})
//    public class EventConsumer {
//        public EventConsumer() {
//        }
//    }
//
//    @ConditionalOnProperty(
//            name = {"com.gang.study.cloud.stream.entity-consumer"},
//            havingValue = "true",
//            matchIfMissing = true
//    )
//    @EnableBinding({SyncEntityConsumer.class})
//    public class EntityConsumer {
//        public EntityConsumer() {
//        }
//    }
//
//    @ConditionalOnProperty(
//            name = {"com.gang.study.cloud.stream.event-producer"},
//            havingValue = "true",
//            matchIfMissing = true
//    )
//    @EnableBinding({SyncEventProducer.class})
//    public class EventProducer {
//        public EventProducer() {
//        }
//    }
//}
//
